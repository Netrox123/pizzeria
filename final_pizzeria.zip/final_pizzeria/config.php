<?php

$conn = mysqli_connect('localhost','root','','user_db');

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "user_db";


$conn = new mysqli($servername, $username, $password, $dbname);

?>