<?php

@include 'config.php';

session_start();

if(!isset($_SESSION['user_name'])){
   header('location:login_form.php');
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Pizzeria</title>
   <link rel="apple-touch-icon" sizes="180x180" href="coski/favicon/apple-touch-icon.png">
   <link rel="icon" type="image/png" sizes="32x32" href="coski/favicon/favicon-32x32.png">
   <link rel="icon" type="image/png" sizes="16x16" href="coski/favicon/favicon-16x16.png">
   <link rel="manifest" href="/site.webmanifest">
   <link rel="stylesheet" href="pizzeria.css">
   <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,100;0,300;0,400;0,700;0,900;1,100;1,300;1,400;1,700;1,900&family=Poppins:wght@300&family=Shantell+Sans:wght@300&display=swap" rel="stylesheet">
</head>
<body>
<navbar>
      <h3 id="logotext">PIZZERIA AMORE</h3>
</navbar>


<div class="box" id="tablice">
<table id="table1">
  <tr>
    <th>Nazwa pizzy</th>
    <th>Składniki</th>
  </tr>
  <?php

  $sql = "SELECT * FROM Pizze";
  $result = $conn->query($sql);

  if ($result->num_rows > 0) {
    
    while($row = $result->fetch_assoc()) {
      echo "<tr>";
      echo "<td>" . $row["Nazwa"] . "</td>";
      echo "<td>" . $row["Skladniki"] . "</td>";
      echo "</tr>";
    }
  } else {
    echo "Nie znaleziono żadnych danych w tabeli Pizze";
  }
  ?>
</table>

<div class="box" id="table2">
<h1>Wybierz pizzę:</h1>
	<form action="user_page.php" method="post">
		<?php
			$conn = new mysqli("localhost", "root", "", "user_db");
         
			$sql = "SELECT * FROM pizze";
			$result = $conn->query($sql);

		
			while($row = $result->fetch_assoc()) {
				echo "<input type='radio' name='pizza_id' value='" . $row['ID'] . "'> " . $row['Nazwa'] . "<br>";
			}
		?>
		<label for="quantity">Ilość sztuk:</label>
		<input type="number" id="quantity" name="quantity" value="1" min="1" max="10">
		<br><br>
		<input type="submit" id="send" value="Wyślij zamówienie">

      <?php
	if ($_SERVER["REQUEST_METHOD"] == "POST") {
      if(isset($_POST["pizza_id"]) && isset($_POST["quantity"])) {
         if($_POST["quantity"] > 0){
            $pizza_id = $_POST["pizza_id"];
            $quantity = $_POST["quantity"];
		      $sql = "INSERT INTO orders (pizza_id, quantity) VALUES ('$pizza_id', '$quantity')";
            mysqli_query($conn, $sql); 
         }
      }
		
		$conn->close();
	}
  ?>
</div>

<div class="box" id="table33">
  <?php
   $servername = "localhost";
   $username = "root";
   $password = "";
   $dbname = "user_db";
   $conn = mysqli_connect($servername, $username, $password, $dbname);

   if (!$conn) {
     die("Connection failed: " . mysqli_connect_error());
   }

   $sql = "SELECT id, pizza_id, quantity FROM orders";
   $result = mysqli_query($conn, $sql);


   if (mysqli_num_rows($result) > 0) {

     echo '<table id="orders-table">';
     echo '<caption>Dane zamówień</caption>';
     echo '<tr><th>ID</th><th>Pizza ID</th><th>Quantity</th></tr>';
     while($row = mysqli_fetch_assoc($result)) {
       echo '<tr><td>' . $row["id"] . '</td><td>' . $row["pizza_id"] . '</td><td>' . $row["quantity"] . '</td></tr>';
     }
     echo '</table>';
   } else {
     echo "0 results";
   }

   mysqli_close($conn); 
?>
</div>
</div>
</body>
</html>